import { HardHat, Boxes, MessageSquare, Plug } from "lucide-react";

const solutions = [
  {
    icon: HardHat,
    title: "Sistemas de RDO Off-line",
    desc: "Controle operacional e de campo com sincronização automática e zero atrito para a ponta.",
  },
  {
    icon: Boxes,
    title: "Rastreabilidade Avançada",
    desc: "Automação ponta a ponta na logística de ativos, eliminando erros humanos de digitação.",
  },
  {
    icon: MessageSquare,
    title: "Hiperautomação Comercial",
    desc: "Triagem, qualificação e roteamento inteligente de leads via WhatsApp e IA integrada ao seu CRM.",
  },
  {
    icon: Plug,
    title: "Integrações ERP & iPaaS",
    desc: "Conexão invisível entre seus sistemas legados (Protheus/SAP) e fluxos modernos via n8n.",
  },
];

export function Sistemas() {
  return (
    <section id="sistemas" className="py-24 md:py-32 border-t border-border bg-muted/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="max-w-3xl">
          <p className="text-xs uppercase tracking-[0.18em] text-brand font-medium">
            Catálogo
          </p>
          <h2 className="mt-4 text-3xl md:text-5xl font-semibold tracking-tight text-foreground leading-[1.1]">
            Sistemas desenhados para{" "}
            <span className="text-muted-foreground">eliminar o trabalho manual.</span>
          </h2>
        </div>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {solutions.map((s, i) => (
            <article
              key={s.title}
              className="group relative bg-background border border-border rounded-xl p-6 transition-all duration-300 hover:-translate-y-1 hover:border-brand/40 hover:shadow-[0_20px_40px_-20px_color-mix(in_oklab,var(--brand)_35%,transparent)]"
            >
              <div className="absolute top-6 right-6 text-xs text-muted-foreground/60 tabular-nums">
                0{i + 1}
              </div>
              <div className="h-11 w-11 rounded-lg bg-brand/10 text-brand grid place-items-center group-hover:bg-brand group-hover:text-brand-foreground transition">
                <s.icon className="h-5 w-5" strokeWidth={1.5} />
              </div>
              <h3 className="mt-6 text-lg font-semibold text-foreground tracking-tight">
                {s.title}
              </h3>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                {s.desc}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
